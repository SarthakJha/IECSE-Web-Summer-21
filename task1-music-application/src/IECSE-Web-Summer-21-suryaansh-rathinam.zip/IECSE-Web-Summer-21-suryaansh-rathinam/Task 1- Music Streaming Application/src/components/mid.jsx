import React, { Component } from 'react'
import play from '../play-icon.png'

// This is a class component
export default class Mid extends Component {
    render() {
        return (
        <div className="row mid">
            <div className="col-lg-1">
                #
            </div>
            <div className="col-lg-6">
                TITLE
            </div>
            <div className="col-lg-3">
            Duration
            </div>
  
            <div>
  
            </div>
          </div>
  
        )
    }
}
