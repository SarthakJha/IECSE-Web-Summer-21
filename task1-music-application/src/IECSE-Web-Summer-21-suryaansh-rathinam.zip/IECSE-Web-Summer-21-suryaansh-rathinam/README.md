# Welcome to Summer Bootcamp 2021

This bootcamp intends to turn you into a full stack developer. We start off with 2 weeks of React.js basics which is a front-end framework. After you guys get comfortable with it, we'll get into server side development with node.js and express. Express is a node based framework which which very popular for backend development. After this you'll learn how to integrate the backend with the front-end and how they work together. Your final week will consist of a project where you'll use everything you have learned to make a full stack application.

Visit the [wiki](https://github.com/SarthakJha/IECSE-Web-Summer-21/wiki) for further instructions





